 # Galaxy Gals
 Members:
  - Josey Zhang
  - Alice Yang
  - Iris Xiang
  - Akshay Gowrishankar
  
 ## Patient Matching Challenge
 
 ## Set up instructions:
 1. The data cleaning portion of this system is in Python. You will need to have the numpy 
	and pandas libraries installed.
 2. Plug in the file path to dataset in the code of the second cell: df = pd.read_csv("yourdata.csv")
 3. Run each cell until the Processing Data heading. The df.head() and df.iloc calles are to 
	check that the dataframe looks as expected and testing that value retrieval.
 4. Next, we have a dictionary of street abbrevitions and state abbreviations. The street abbreviations
	are not comprehensive, so feel free to add more. 
 5. Run the remaining cells, and the functions for data processing can be edited depending
	on what format is determined to be the desired standardized format. Ours is listed
	under processing data. 
 6. Next, open the PAM_clustering.R file. Make sure that you have the cluster, dplyr, ggplot2, 
	readr, and Rtsne packages installed. 
 7. Make sure that you are in your desired directory. setwd("/Directory/Path") can be used to 
	set the directory, and rm(list=ls()) should be called to remove any previous environment variables. 
 8. Change the file name in df <- read.csv("patient3.csv") to the proper dataset
 9. Run the section of code before the Summary of clusters heading. This will calculate the 
	dissimilarity matrix and the silhouette graph will appear. The optimal cluster configuration can 
	be obtain through the graph and its data points. We want the least cluster number while minimizing 
	the loss of high value from the cluster number above it. 
 10. Run the section of code until the Visualization heading. This is the pam, or k-medoids algorithm
	The pam_fit$silinfo call gives information about which rows belong to which cluster. 
 11. Run the Visualization code. This will result in a graph of the clusters, with each cluster represented
	by a different color on the gradient. 
 
 ## Proof of Concept Steps
 1. In the data cleaning portion of the algorithm, we used the pandas library, which has 
	many useful functions for cleaning data. First, we replaced all missing values with 
	zeros. We chose this value because a single zero actually appears very infrequently on 
	patient records, and will not raise errors in algorithms but can be easily type checked 
	against the common data input of type string to determine that it represents a missing value. 
	Next, we created dictionaries of address abbreviations (Drive to Dr, etc.) and state 
	abbreviations (Wyoming to WY), so that after reducing all strings in those features 
	to a common lower or uppercase font, we could search for a substring of the abbreviation 
	and for strings of the non abbreviated form to reduce all strings to either an abbreviated 
	form or expand to a non abbreviated form. We chose to reduce all address/state inputs 
	to an abbreviated form, as searching for abbreviations in strings can yield false 
	results, such as finding “OR” in a word instead of when it is used to represent Wyoming. We 
	also removed characters such as “#” and “/”, which are common among dates and address but 
	causes encoding issues in algorithms. 

2. Next step is clustering. Before we implement the k-medoids algorithm, we used the 
	silhouette method to determine the number of clusters we should use as a parameter in 
	k-medoids. A silhouette value is a value between -1 and +1, where the higher the value the 
	better the match between an object and its cluster, in comparison to its neighboring 
	clusters. We look for a maximization of objects with a high value, and the clustering 
	configuration that provides that is the one we select. Although the silhouette method can 
	use any distance metric, we employed Manhattan distance over Euclidean distance, since 
	Euclidean distance is easily influenced by unusual values, and since much of our data was 
	originally categorical, unusual values are not uncommon. 
  
3. Then, we use gower’s distance algorithm to produce a dissimilarity matrix of our 
	patient vectors. Gower’s algorithm works by assigning weights to categorical variables, 
	and assigning them such that each categorical value can be transformed into a numerical 
	value, but keep its relative comparison with other similar values in its category. Then, 
	the distance is calculated between each categorical to numerical value between different 
	patient vectors, and then combined for that vector, using Manhattan distance (which is 
	what we used) or another distance algorithm. The output is a dissimilarity matrix whose 
	values become data points in the k-medoids clustering algorithm. K-medoids clustering 
	works as the following:
	
	1.	Select *k* of the *n* data points as medoids using a greedy algorithm, where *k* 
		is the predetermined number of clusters, and *n* is number of data points available 
		from the dissimilarity matrix. 
	2. For each remaining data point, calculate their distance to each of the medoids, 
		and selects the medoid the shortest distance away. Distance is defined in this 
		situation as the sum of dissimilarities between the two points. 
	3.	For each medoid, take each of the non-medoid data points, and compute the cost of 
		swapping them. Cost is defined in this situation as the new sum of dissimilarities 
		between the new medoid and points in their cluster. If this cost is better than the 
		previous cost, we make the swap permanent and set this value as the new best cost. 
	4.	We repeat until we can no longer find a swap that decreases the cost. 
	
 
 
 ## Summary of Results  
 
 We were able to acheive 95% accuracy with our algorithm. Accuracy is determined as percent of 
 correct matches (correct patient record in complete correct group). 

 
 ## Contact Info
 * Josey Zhang: jzhang7@caltech.edu 
 * Alice Yang: aliceyang121@caltech.edu
 * Iris Xiang: xxxiang@caltech.edu
 * Akshay Growrishankar: agowrish@caltech.edu
 